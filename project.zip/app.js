const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

// In-memory database
let students = [];

// POST endpoint to add a student
app.post('/students', (req, res) => {
    const { id, name, gpa } = req.body;
    students.push({ id, name, gpa });
    res.status(201).send('Student added successfully');
});

// GET endpoint to retrieve all students
app.get('/students', (req, res) => {
    res.json(students);
});

// GET endpoint to retrieve a student by ID
app.get('/students/:id', (req, res) => {
    const studentId = req.params.id;
    const student = students.find(s => s.id === studentId);
    if (student) {
        res.json(student);
    } else {
        res.status(404).send('Student not found');
    }
});

// GET endpoint to find the topper
app.get('/topper', (req, res) => {
    if (students.length === 0) {
        return res.status(404).send('No students available');
    }

    let topper = students.reduce((max, student) => {
        return (student.gpa > max.gpa) ? student : max;
    });

    res.json({
        id: topper.id,
        name: topper.name
    });
});

app.listen(port, () => {
    console.log('Server is running on http://localhost:${port}');
});